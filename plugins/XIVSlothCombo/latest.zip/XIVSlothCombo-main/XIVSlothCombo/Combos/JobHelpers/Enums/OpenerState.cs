﻿namespace XIVSlothCombo.Combos.JobHelpers.Enums
{
    internal enum OpenerState
    {
        PrePull,
        InOpener,
        OpenerFinished,
        FailedOpener
    }
}
