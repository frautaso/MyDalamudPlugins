﻿namespace XIVSlothCombo.Combos.PvE
{
    internal static class DOH
    {
        public const byte ClassID = 0;
        public const byte JobID = 50;

        public const uint
            Placeholder = 0;

        public static class Buffs
        {
            public const ushort
                Placeholder = 0;
        }

        public static class Debuffs
        {
            public const ushort
                Placeholder = 0;
        }
    }
}