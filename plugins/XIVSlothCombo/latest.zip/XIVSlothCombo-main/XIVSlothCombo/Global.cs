﻿global using static XIVSlothCombo.XIVSlothCombo;
